import os
import argparse
import wandb
import torch
import transformers
import numpy as np
from tqdm import tqdm
from huggingface_hub import login as hf_login
from transformers import AutoTokenizer, AutoModelForCausalLM, DataCollatorForLanguageModeling
from datasets import Dataset
from peft import PeftModel
from torchmetrics.classification import MulticlassCalibrationError
from typing import Tuple, List, Dict

# Assuming 'model.py' and 'data.py' are in the same directory or accessible
from model import load_peft_model_and_adapter # We use the base loader, then add the adapter
from data import multiple_choice_prompt_engineer, load_classification_dataset
from utils import setup_environment

def parse_args() -> argparse.Namespace:
    """Sets up and parses command-line arguments for inference."""
    parser = argparse.ArgumentParser(description="Run MC Dropout inference on a fine-tuned MoE model.")
    parser.add_argument("--param_num", type=str, default="3b", choices=["1b", "3b"], help="Model parameter size.")
    parser.add_argument("--adapter_path", type=str, required=True, help="Path to the trained PEFT adapter directory.")
    parser.add_argument("--dataset_name", type=str, default="arc_easy", help="Dataset to use for evaluation.")
    parser.add_argument("--num_samples", type=int, default=10, help="Number of Monte Carlo samples per input.")
    parser.add_argument("--batch_size", type=int, default=4, help="Batch size for inference.")
    return parser.parse_args()

def main():
    """Main function to orchestrate the MC Dropout inference and evaluation process."""
    args = parse_args()
    setup_environment()

    # --- Load Dependencies ---
    model = load_peft_model_and_adapter(args.param_num, args.adapter_path)
    tokenizer = AutoTokenizer.from_pretrained(args.adapter_path) # Load tokenizer from adapter dir
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    # --- Prepare Data ---
    _, _, test_raw = load_classification_dataset(args.dataset_name)
    test_dataset = [multiple_choice_prompt_engineer(x, tokenizer=tokenizer) for x in test_raw]
    questions = [x['question'] for x in test_dataset]
    true_answers = [x['answer'] for x in test_dataset]
    true_answer_ids = [tokenizer.convert_tokens_to_ids(ans) for ans in true_answers]
    
    # --- Configure WandB ---
    project_name = "exp3_mc_dropout_inference"
    exp_name = f"inference_{os.path.basename(args.adapter_path)}_samples_{args.num_samples}"
    wandb.init(project=project_name, name=exp_name, config=vars(args))

    # --- Run MC Dropout Inference ---
    all_final_probs = []
    model.to("cuda" if torch.cuda.is_available() else "cpu")
    
    # Set the router mode for stochastic inference
    model.change_router_mode("mc_dropout_stochastic_logits")

    with torch.no_grad():
        for i in tqdm(range(0, len(questions), args.batch_size), desc="Running MC Inference"):
            batch_questions = questions[i:i+args.batch_size]
            
            inputs = tokenizer(
                batch_questions,
                return_tensors="pt",
                padding=True,
                truncation=True
            ).to(model.device)

            batch_mc_probs = []
            for _ in range(args.num_samples):
                # Each forward pass will have different dropout masks
                outputs = model(**inputs)
                next_token_logits = outputs.logits[:, -1, :]
                probs = torch.softmax(next_token_logits, dim=-1)
                batch_mc_probs.append(probs)

            # Average the probabilities across all MC samples
            # Stack along a new dimension (dim=0) and then take the mean
            avg_probs = torch.stack(batch_mc_probs, dim=0).mean(dim=0)
            all_final_probs.append(avg_probs.cpu())

    # Concatenate all batch results
    final_probs_tensor = torch.cat(all_final_probs, dim=0)
    
    # --- Calculate Metrics ---
    # Predictions
    pred_indices = torch.argmax(final_probs_tensor, dim=-1)
    preds = [tokenizer.decode(idx) for idx in pred_indices.tolist()]
    
    # Accuracy
    accuracy = sum([p == t for p, t in zip(preds, true_answers)]) / len(true_answers)
    
    # NLL
    # Use the probabilities of the true answers for NLL calculation
    nlls = -torch.log(final_probs_tensor[torch.arange(len(true_answer_ids)), true_answer_ids]).tolist()
    nll_avg = np.mean(nlls)
    nll_std = np.std(nlls)
    
    # Entropy
    entropies = -torch.sum(final_probs_tensor * torch.log(final_probs_tensor), dim=-1).tolist()
    ent_avg = np.mean(entropies)
    ent_std = np.std(entropies)
    
    # ECE
    # For ECE, we need logits. We can approximate them from the averaged probabilities.
    # Note: This is an approximation. A more direct way would be to average logits, but averaging probabilities is standard for MC dropout.
    pseudo_logits = torch.log(final_probs_tensor)
    targets_tensor = torch.tensor(true_answer_ids)
    
    metrics_to_log = {
        "accuracy": accuracy,
        "nll_avg": nll_avg,
        "nll_std": nll_std,
        "entropy_avg": ent_avg,
        "entropy_std": ent_std,
    }
    
    for n_bins in [10, 15, 20]:
        ece_metric = MulticlassCalibrationError(num_classes=model.config.vocab_size, n_bins=n_bins, norm='l1')
        ece = ece_metric(pseudo_logits, targets_tensor).item()
        metrics_to_log[f"ece_{n_bins}"] = ece

    print("--- Final Metrics ---")
    for key, value in metrics_to_log.items():
        print(f"{key}: {value:.4f}")
    
    wandb.log(metrics_to_log)
    wandb.finish()
    print("Inference and evaluation complete.")

if __name__ == "__main__":
    main()
