from .granitemoe.modeling_granitemoe import GraniteMoeForCausalLM
from transformers import AutoModelForCausalLM, PreTrainedModel
import torch
from peft import LoraConfig, get_peft_model, TaskType

def load_model(model_id: str, device_map: str = "auto"):
    """
    Load a model based on the provided model_id.
    """
    if "granite" in model_id:
        return GraniteMoeForCausalLM.from_pretrained(model_id, device_map=device_map)
        # return AutoModelForCausalLM.from_pretrained(model_id, device_map=device_map)
    else:
        return AutoModelForCausalLM.from_pretrained(model_id, device_map=device_map)

def load_peft_model(model_id: str, finetune_mode: str, r: int = 64, lora_dropout: float = 0.1) -> PreTrainedModel:
    """Loads the base model and applies LoRA configuration."""
    base_model = load_model(model_id)
    base_model.config.use_cache = False
    base_model.config.pretraining_tp = 1

    # Define LoRA target modules based on the finetune mode
    if finetune_mode == "router":
        # This assumes your gating layer's nn.Linear is named 'layer'
        # and the gating module itself is named 'gating_layer'.
        # Adjust if your model's naming convention is different.
        target_modules = ["router.layer"]
    elif finetune_mode == "qkv":
        # A common choice for general fine-tuning
        target_modules = ["q_proj", "k_proj", "v_proj"]
    else:
        raise ValueError(f"Unknown finetune mode: {finetune_mode}")

    peft_config = LoraConfig(
        lora_alpha=16,
        lora_dropout=lora_dropout,
        r=r,
        bias="none",
        task_type=TaskType.CAUSAL_LM,
        target_modules=target_modules
    )

    peft_model = get_peft_model(base_model, peft_config)
    peft_model.print_trainable_parameters()
    
    return peft_model

def load_peft_model_and_adapter(model_id: str, adapter_path: str) -> PeftModel:
    """Loads the base model and applies the trained LoRA adapter."""

    print(f"Loading base model: {model_id}")
    base_model = load_model(model_id)
    
    print(f"Loading PEFT adapter from: {adapter_path}")
    peft_model = PeftModel.from_pretrained(base_model, adapter_path)
    peft_model.eval() # Set model to evaluation mode
    
    return peft_model