import os
import json
import datasets
import hashlib
from datasets import Dataset
from typing import List
from transformers import AutoTokenizer

def load_generation_dataset(dataset_name, seed=42):
    """
    Load dataset.
    Input: dataset_name;
    Output: train_dataset, validation_dataset;
    """

    train_dataset, validation_dataset = None, None

    if dataset_name == "squad":
        dataset = datasets.load_dataset("squad_v2")
        train_dataset = dataset["train"]
        validation_dataset = dataset["validation"]

    elif dataset_name == 'svamp':
        dataset = datasets.load_dataset('ChilleD/SVAMP')
        train_dataset = dataset["train"]
        validation_dataset = dataset["test"]

        reformat = lambda x: {
            'question': x['Question'], 'context': x['Body'], 'type': x['Type'],
            'equation': x['Equation'], 'id': x['ID'],
            'answers': {'text': [str(x['Answer'])]}
        }

        train_dataset = [reformat(d) for d in train_dataset]
        validation_dataset = [reformat(d) for d in validation_dataset]

    elif dataset_name == 'nq':
        dataset = datasets.load_dataset("nq_open")
        train_dataset = dataset["train"]
        validation_dataset = dataset["validation"]
        md5hash = lambda s: str(int(hashlib.md5(s.encode('utf-8')).hexdigest(), 16))

        reformat = lambda x: {
            'question': x['question']+'?',
            'answers': {'text': x['answer']},
            'context': '',
            'id': md5hash(str(x['question'])),
        }

        train_dataset = [reformat(d) for d in train_dataset]
        validation_dataset = [reformat(d) for d in validation_dataset]

    elif dataset_name == "trivia_qa":
        dataset = datasets.load_dataset('TimoImhof/TriviaQA-in-SQuAD-format')['unmodified']
        dataset = dataset.train_test_split(test_size=0.2, seed=seed)
        train_dataset = dataset['train']
        validation_dataset = dataset['test']

    elif dataset_name == "bioasq":
        # http://participants-area.bioasq.org/datasets/ we are using training 11b
        # could also download from here https://zenodo.org/records/7655130
        dataset = datasets.load_dataset("albusli/bioasq-training11b")
        train_dataset = dataset["train"]
        validation_dataset = dataset["test"]

    else:
        raise ValueError

    return train_dataset, validation_dataset
    
def load_classification_dataset(dataset_name, seed=42):
    """
    Load dataset.
    Input: dataset_name;
    Output: train_dataset, validation_dataset;
    in [{"id": str, "question": str, "answer": str}] format;
    """

    if dataset_name == "openbookqa":
        dataset = datasets.load_dataset("openbookqa", "main")
        def reformat(example):
            id = example["id"]
            question = example["question_stem"]
            choices = example["choices"]["text"]
            labels = example["choices"]["label"]
            answer = example["answerKey"]
            return {
                'question': f"Question: {question}\nChoices:\n" 
                           + "\n".join([f"{label}. {choice}" for label, choice in zip(labels, choices)]) + "\nAnswer:",
                'answer': answer,
                'id': id,
            }
    elif "winogrande" in dataset_name: 
        # s, m, l, xl: same test/validation size, only train size different
        dataset = datasets.load_dataset("winogrande", dataset_name)
        def reformat(example):
            id = example["id"]
            question = example["sentence"]
            choices = [example["option1"], example["option2"]]
            labels = ["1", "2"]
            answer = example["answer"]
            return {
                'question': f"Question: {question}\nChoices:\n" 
                           + "\n".join([f"{label}. {choice}" for label, choice in zip(labels, choices)]),
                'answer': answer,
                'id': id,
            }
    elif "arc" in dataset_name:
        # "arc_easy", "arc_challenge"
        assert dataset_name in ["arc_easy", "arc_challenge"]
        dataset = datasets.load_dataset("ai2_arc", "ARC-Challenge" if "challenge" in dataset_name else "ARC-Easy")
        def reformat(example):
            id = example["id"]
            question = example["question"]
            choices = example["choices"]["text"]
            labels = example["choices"]["label"]
            answer = example["answerKey"]
            return {
                'question': f"Question: {question}\nChoices:\n" 
                           + "\n".join([f"{label}. {choice}" for label, choice in zip(labels, choices)]) + "\nAnswer:",
                'answer': answer,
                'id': id,
            }
    elif dataset_name == "boolq":
        dataset = datasets.load_dataset("boolq")
        def reformat(example):
            question = example["question"]
            answer = example["answer"]
            context = example["passage"]
            return {
                'question': f"Context: {context}\nQuestion: {question}",
                'answer': answer
            }
    else:
        raise ValueError
    
    train_dataset = dataset["train"]
    validation_dataset = dataset["validation"]
    test_dataset = dataset["test"]

    # TODO: temp change for arc_easy/challenge
    train_dataset = [reformat(d) for d in train_dataset if d["choices"]["label"] == ["A", "B", "C", "D"]]
    validation_dataset = [reformat(d) for d in validation_dataset if d["choices"]["label"] == ["A", "B", "C", "D"]]
    test_dataset = [reformat(d) for d in test_dataset if d["choices"]["label"] == ["A", "B", "C", "D"]]

    return train_dataset, validation_dataset, test_dataset

def batchify(data, batch_size, tokenizer, device="auto"):
    """
    Create batches of data and handle padding.
    """
    for i in range(0, len(data), batch_size):
        batch = data[i:i + batch_size]

        # Extract input texts and answers
        questions = [item["question"] for item in batch]
        answers = [item["answer"] for item in batch]
        ids = [item["id"] for item in batch]

        # Tokenize and pad
        inputs = tokenizer(
            questions,
            return_tensors="pt",
            padding=True,  # Pad to the longest sequence in the batch, CRUCIAL
            truncation=True
        ).to(device)

        yield inputs, answers, ids

def preprocess_mask_question_for_training(dataset_list: List[dict], tokenizer: AutoTokenizer) -> Dataset:
    """Correctly tokenizes and masks the dataset for supervised fine-tuning."""
    IGNORE_INDEX = -100
    prompts = [item['question'] for item in dataset_list]
    full_texts = [item['question'] + item['answer'] for item in dataset_list]
    # Tokenize the full texts to get input_ids
    model_inputs = tokenizer(full_texts, padding="longest", truncation=False)
    # Tokenize prompts separately to find their lengths for masking
    # We don't add special tokens here because we only care about the length of the prompt text itself
    prompt_lengths = [len(tokenizer(p, add_special_tokens=False).input_ids) for p in prompts]
    
    labels_list = []
    for i, input_id_row in enumerate(model_inputs['input_ids']):
        prompt_len = prompt_lengths[i]
        # The label is a copy of the input_ids
        label_row = list(input_id_row)
        
        # Mask the prompt part by setting it to IGNORE_INDEX
        # The first token is often BOS, which should also be masked.
        # We mask up to the length of the tokenized prompt.
        for j in range(prompt_len):
            label_row[j] = IGNORE_INDEX
        labels_list.append(label_row)
    
    model_inputs["labels"] = labels_list
    return Dataset.from_dict(model_inputs)